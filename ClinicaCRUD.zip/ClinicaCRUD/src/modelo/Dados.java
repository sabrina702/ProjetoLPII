/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 13912471673
 */
public class Dados {
    
    public static List<Cliente> listaCliente = new ArrayList<>();
    public static List<Funcionario> listaFuncionario = new ArrayList<>();
    public static List<Categoria> listaCategoria = new ArrayList<>();
    public static List<Procedimento> listaProcedimento = new ArrayList<>();
    public static List<Consulta> listaConsulta = new ArrayList<>();
    
}
