/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author 13912471673
 */
public class DAOProcedimento {
    DAOCategoria objDAOCAtegoria = new DAOCategoria();
   
    public List<Procedimento> getLista(){ 
        String sql = "select * from procedimento";
        List <Procedimento> listaProcedimento = new ArrayList<>();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                Procedimento objProcedimento = new Procedimento();
                objProcedimento.setCodigoProcedimento(rs.getInt("codigoProcedimento"));
                objProcedimento.setNomeProcedimento(rs.getString("nome"));
                objProcedimento.setObjCategoria(objDAOCAtegoria.localizar(rs.getInt("Categoria")));
                listaProcedimento.add(objProcedimento);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no getLista() do DAOProcedimento: "+ex.getMessage());
        }
        return listaProcedimento;
        }
    
    
    public boolean salvar(Procedimento obj) {
        if (obj.getCodigoProcedimento()== null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
    
    public boolean incluir(Procedimento obj) {
        String sql = "insert into procedimento (nome,categoria) values(?,?)";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNomeProcedimento());
            pst.setInt(2, obj.getObjCategoria().getCodigoCategoria());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Procedimento incluido");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Procedimento não incluido");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no incluir do DAOProcedimento" + e.getMessage());

        }
        return false;
    }
      
    public boolean alterar(Procedimento obj) {
        String sql = "update Procedimento set nome=?, categoria=? where codigoProcedimento=?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNomeProcedimento());
            pst.setInt(2, obj.getObjCategoria().getCodigoCategoria());
            pst.setInt(3, obj.getCodigoProcedimento());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Procedimento alterado");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Procedimento não alterado");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no alterar do DAOProcedimento" + e.getMessage());

        }
        return false;
    }
    
    public boolean remover(Procedimento obj){
         String sql = "delete from Procedimento where codigoProcedimento=?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getCodigoProcedimento());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Procedimento removido");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Procedimento não removido");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no remover do DAOProcedimento" + e.getMessage());

        }
        return false;
    }
    
    public Procedimento localizar(Integer id){
        String sql = "select * from procedimento where codigoProcedimento=?";
        Procedimento obj = new Procedimento();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
        while(rs.next()){
                        obj.setCodigoProcedimento(rs.getInt("codigoProcedimento"));
                        obj.setNomeProcedimento(rs.getString("nome"));
                        return obj;
                    }
        }catch(SQLException e){
                    JOptionPane.showMessageDialog
                (null,"Erro de SQL Localizar"+e.getMessage());
            }
                return null;
         }    
    
}
