/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author 13912471673
 */
public class DAOCategoria {
    public List<Categoria> getLista(){ 
        String sql = "select * from categoria";
        List <Categoria> listaCategoria = new ArrayList<>();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                Categoria objCategoria = new Categoria();
                objCategoria.setCodigoCategoria(rs.getInt("codigoCategoria"));
                objCategoria.setNomeCategoria(rs.getString("nome"));
                listaCategoria.add(objCategoria);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no getLista() do DAOCategoria: "+ex.getMessage());
        }
        return listaCategoria;
        }
    
    
    public boolean salvar(Categoria obj) {
        if (obj.getCodigoCategoria()== null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
    
    public boolean incluir(Categoria obj) {
        String sql = "insert into categoria (nome) values(?)";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNomeCategoria());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Categoria incluida");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Categoria não incluida");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no incluir do DAOCategoria" + e.getMessage());

        }
        return false;
    }
      
    public boolean alterar(Categoria obj) {
        String sql = "update categoria set nome=?  where codigoCategoria=?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNomeCategoria());
            pst.setInt(2, obj.getCodigoCategoria());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Categoria alterada");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Categoria não alterada");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no alterar do DAOCategoria" + e.getMessage());

        }
        return false;
    }
    
    public boolean remover(Categoria obj){
         String sql = "delete from Categoria where codigoCategoria=?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getCodigoCategoria());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Categoria removida");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Categoria não removida");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no remover do DAOCategoria" + e.getMessage());

        }
        return false;
    }
    
    public Categoria localizar(Integer id){
        String sql = "select * from categoria where codigoCategoria=?";
        Categoria obj = new Categoria();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
        while(rs.next()){
                        obj.setCodigoCategoria(rs.getInt("codigoCategoria"));
                        obj.setNomeCategoria(rs.getString("nome"));
                        return obj;
                    }
        }catch(SQLException e){
                    JOptionPane.showMessageDialog
                (null,"Erro de SQL Localizar"+e.getMessage());
            }
                return null;
        }
    
}
