/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author 13912471673
 */
public class DAOConsulta {
    
    DAOCliente objDAOCliente = new DAOCliente();
    DAOFuncionario objDAOFuncionario = new DAOFuncionario();
    DAOProcedimento objDAOProcedimento = new DAOProcedimento();
    
    public List<Consulta> getLista(){ 
        String sql = "select * from Consulta";
        List <Consulta> listaConsulta = new ArrayList<>();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                Consulta objConsulta = new Consulta();
                objConsulta.setIdConsulta(rs.getInt("idConsulta"));
                objConsulta.setValorConsulta(rs.getDouble("valor"));
                java.sql.Date dt = rs.getDate("data");
                Calendar c = Calendar.getInstance();
                c.setTime(dt);
                objConsulta.setData(c);
                objConsulta.setHora(rs.getString("hora"));
                objConsulta.setObjCliente(objDAOCliente.localizar(rs.getInt("Cliente")));
                objConsulta.setObjFuncionario(objDAOFuncionario.localizar(rs.getInt("Funcionario")));
                objConsulta.setObjProcedimento(objDAOProcedimento.localizar(rs.getInt("Procedimento")));
                listaConsulta.add(objConsulta);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no getLista() do DAOConsulta: "+ex.getMessage());
        }
        return listaConsulta;
        }
    
    public boolean salvar(Consulta obj) {
        if (obj.getIdConsulta()== null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
    
    public boolean incluir(Consulta obj) {
        String sql = "insert into Consulta (valor, cliente, funcionario, procedimento,data, hora) values(?,?,?,?,?,?)";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setDouble(1, obj.getValorConsulta());
            pst.setInt(2, obj.getObjCliente().getCodigoCliente());
            pst.setInt(3, obj.getObjFuncionario().getCodigoFuncionario());
            pst.setInt(4, obj.getObjProcedimento().getCodigoProcedimento());
            pst.setDate(5, new java.sql.Date(obj.getData().getTimeInMillis()));
            pst.setString(6, obj.getHora());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Consulta incluido");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Consulta não incluido");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no incluir do DAOConsulta" + e.getMessage());

        }
        return false;
    }
      
    public boolean alterar(Consulta obj) {
        String sql = "update Consulta set cliente=? , funcionario=? ,procedimento=?, valor=?, data=?, hora=? where idConsulta=?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getObjCliente().getCodigoCliente());
            pst.setInt(2, obj.getObjFuncionario().getCodigoFuncionario());
            pst.setInt(3, obj.getObjProcedimento().getCodigoProcedimento());
            pst.setDouble(4, obj.getValorConsulta());
            pst.setDate(5, new java.sql.Date(obj.getData().getTimeInMillis()));
            pst.setString(6, obj.getHora());
            pst.setInt(7, obj.getIdConsulta());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Consulta alterada");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Consulta não alterado");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no alterar do DAOConsulta" + e.getMessage());

        }
        return false;
    }
    
    public boolean remover(Consulta obj){
         String sql = "delete from Consulta where idConsulta=?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getIdConsulta());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Consulta removido");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Consulta não removido");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no remover do DAOConsulta" + e.getMessage());

        }
        return false;
    }    
     
}
