/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author 13912471673
 */
public class DAOCliente {
    
    public List<Cliente> getLista(){ 
        String sql = "select * from cliente";
        List <Cliente> listaCliente = new ArrayList<>();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                Cliente objCliente = new Cliente();
                objCliente.setCodigoCliente(rs.getInt("codigoCliente"));
                objCliente.setNomeCliente(rs.getString("nome"));
                java.sql.Date dt = rs.getDate("dataNascimento");
                Calendar c = Calendar.getInstance();
                c.setTime(dt);
                
                objCliente.setNascimentoCliente(c);
                listaCliente.add(objCliente);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no getLista() do DAOCliente: "+ex.getMessage());
        }
        return listaCliente;
        }
    
    
    public boolean salvar(Cliente obj) {
        if (obj.getCodigoCliente()== null) {
            return incluir(obj);
        } else {
            return alterar(obj);
        }
    }
    
    public boolean incluir(Cliente obj) {
        String sql = "insert into Cliente (nome,dataNascimento) values(?,?)";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNomeCliente());
            pst.setDate(2, new java.sql.Date(obj.getNascimentoCliente().getTimeInMillis()));
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Cliente incluido");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Cliente não incluido");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no incluir do DAOCliente" + e.getMessage());

        }
        return false;
    }
      
    public boolean alterar(Cliente obj) {
        String sql = "update Cliente set nome=?, dataNascimento=?  where codigoCliente=?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNomeCliente());
            pst.setDate(2, new java.sql.Date(obj.getNascimentoCliente().getTimeInMillis()));
            pst.setInt(3, obj.getCodigoCliente());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Cliente alterada");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Cliente não alterado");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no alterar do DAOCliente" + e.getMessage());

        }
        return false;
    }
    
    public boolean remover(Cliente obj){
         String sql = "delete from Cliente where codigoCliente=?";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getCodigoCliente());
            if (pst.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Cliente removido");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Cliente não removido");
                return false; 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro de SQL no remover do DAOCliente" + e.getMessage());

        }
        return false;
    }    
        public Cliente localizar(Integer id){
        String sql = "select * from Cliente where codigoCliente=?";
        Cliente obj = new Cliente();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
        while(rs.next()){
                        obj.setCodigoCliente(rs.getInt("codigoCliente"));
                        obj.setNomeCliente(rs.getString("nome"));
                        return obj;
                    }
        }catch(SQLException e){
                    JOptionPane.showMessageDialog
                (null,"Erro de SQL Localizar"+e.getMessage());
            }
                return null;
        } 
}
